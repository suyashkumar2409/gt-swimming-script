Swimming Script for MCAuley Aquatic Center.

Fetches events from the website and updates a Google Calendar.

The calendar can be subscribed to [here]().

I build and write about more cool stuff [here](https://www.suyash-kumar.com).