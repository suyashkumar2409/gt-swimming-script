from service.calendar.google_calendar import GoogleCalendar

gc = GoogleCalendar()
gc.clear_calendar()